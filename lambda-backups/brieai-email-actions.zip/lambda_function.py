import json
import boto3

def lambda_handler(event, context):
    print(f"Event: {json.dumps(event)}")
    
    try:
        # Configuración SES
        ses_client = boto3.client('ses', region_name='us-east-1')
        from_email = 'ugrosso@bigcheese.com.uy'
        to_email = 'ugrosso@bigcheese.com.uy'
        
        # Extraer parámetros
        params = {}
        for param in event.get('parameters', []):
            params[param['name']] = param['value']
        
        subject = params.get('subject', 'Información de BrieAI')
        content = params.get('content', '')
        
        # HTML template
        html_body = f"""
        <div style="font-family: 'Montserrat', Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #D4D0CB; padding: 20px;">
            <div style="background-color: white; padding: 30px; border-radius: 10px;">
                <h1 style="color: #ABA0FB; text-align: center;">📊 BrieAI</h1>
                <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <pre style="white-space: pre-wrap; font-family: 'Montserrat', Arial, sans-serif; margin: 0; color: #1A1A1A; line-height: 1.6;">{content}</pre>
                </div>
                <p style="text-align: center; color: #666; font-size: 14px;">
                    Enviado por <strong style="color: #ABA0FB;">BrieAI</strong>
                </p>
            </div>
        </div>
        """
        
        # Enviar email
        response = ses_client.send_email(
            Source=from_email,
            Destination={'ToAddresses': [to_email]},
            Message={
                'Subject': {'Data': subject, 'Charset': 'UTF-8'},
                'Body': {
                    'Html': {'Data': html_body, 'Charset': 'UTF-8'},
                    'Text': {'Data': content, 'Charset': 'UTF-8'}
                }
            }
        )
        
        # Respuesta para Bedrock Agent
        return {
            'messageVersion': '1.0',
            'response': {
                'actionGroup': event.get('actionGroup', ''),
                'apiPath': event.get('apiPath', ''),
                'httpMethod': event.get('httpMethod', ''),
                'httpStatusCode': 200,
                'responseBody': {
                    'application/json': {
                        'body': json.dumps({
                            'success': True,
                            'message': f'Email enviado exitosamente a {to_email}',
                            'messageId': response['MessageId']
                        })
                    }
                }
            }
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'messageVersion': '1.0',
            'response': {
                'actionGroup': event.get('actionGroup', ''),
                'apiPath': event.get('apiPath', ''),
                'httpMethod': event.get('httpMethod', ''),
                'httpStatusCode': 500,
                'responseBody': {
                    'application/json': {
                        'body': json.dumps({
                            'error': f'Error: {str(e)}'
                        })
                    }
                }
            }
        }